# Smart Hospital Assistant — Python Chatbot Service

A standalone Flask microservice that powers an AI chatbot widget for your
existing PHP Hospital Management System. This service runs alongside your
PHP project — it does **not** replace, rewrite, or modify any part of it.

```
PHP Website → JS Chat Widget → AJAX → Flask API (this project) → MySQL → JSON → Chat Widget
```

---

## ✅ Phase 1 — Completed

This phase sets up the foundation:

- Flask app skeleton (`app.py`)
- Centralized config (`config.py`)
- MySQL connection pooling to your **existing** database (`database.py`)
- CORS restricted to your PHP site's origin(s)
- `/api/health` endpoint to verify the service + DB connection are alive

### Project structure so far

```
chatbot/
├── app.py              # Flask entry point
├── config.py            # All settings (env-driven)
├── database.py           # MySQL connection pool + helpers
├── requirements.txt
├── .env.example          # Copy to .env and fill in real DB credentials
├── static/                # (reserved for Phase 2: chat.js, style.css)
├── templates/             # (reserved, likely unused since chat widget lives in PHP)
└── README.md
```

---

## Setup Instructions

### 1. Create a virtual environment (recommended)

```bash
cd chatbot
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure your database connection

```bash
cp .env.example .env
```

Edit `.env` and enter the **same MySQL credentials your PHP project already
uses** (check your PHP project's `db.php` / `config.php` for host, user,
password, and database name). This service reads from the same database —
it does not need a new one.

### 4. Run the service

```bash
python app.py
```

You should see Flask start on:

```
http://localhost:5000
```

### 5. Test it

Open in your browser or use curl:

```bash
curl http://localhost:5000/api/health
```

Expected response if everything is connected correctly:

```json
{
  "service": "Smart Hospital Assistant API",
  "status": "ok",
  "database_connected": true
}
```

If `database_connected` is `false`, double-check the `DB_*` values in your
`.env` file against your PHP project's database config.

---

## Important Notes

- **No existing PHP files were touched.** This is a completely separate
  service that talks to your database independently.
- **Read-only by default.** The `ALLOW_WRITE_OPERATIONS` flag in `.env` is
  `False` and will stay that way until a phase explicitly requires writing
  data (e.g., booking an appointment through the chatbot).
- **CORS is locked down** to only the origin(s) you list in
  `ALLOWED_ORIGINS`, so random websites can't call your chatbot API.

---

## What's Next

Once you confirm Phase 1 is working (i.e., `/api/health` returns
`database_connected: true` against your real database), we'll move to:

**Phase 2 — Chat UI + AJAX + PHP Integration**
- Floating chat widget (`static/style.css`, `static/chat.js`)
- The exact PHP snippet to drop into your existing pages (e.g., a shared
  footer/include) so the widget appears site-wide without touching your
  core logic
- AJAX calls from the widget to this Flask API

Let me know once Phase 1 is verified on your machine, and I'll proceed to
Phase 2.
