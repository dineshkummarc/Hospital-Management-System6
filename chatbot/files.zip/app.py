"""
app.py
------
Entry point for the Smart Hospital Assistant Flask API.

This is a STANDALONE Python service. It runs separately from your PHP
project (different process, typically a different port such as 5000).
Your PHP pages will call this API using AJAX/fetch over HTTP — nothing
in your PHP codebase needs to be rewritten.

Run locally:
    pip install -r requirements.txt
    python app.py

The API will start at:
    http://localhost:5000

Phase 1 only includes:
    - Flask app + CORS setup
    - A health check endpoint that also verifies the MySQL connection

Later phases will add:
    /api/chat            -> main chatbot endpoint (symptom engine, intents)
    /api/doctors          -> doctor search
    /api/appointments     -> appointment lookups
    /api/prescriptions    -> prescription lookups
    /api/faq              -> hospital FAQ answers
"""

from flask import Flask, jsonify
from flask_cors import CORS

from config import Config
from database import test_connection

app = Flask(__name__)

# Only allow your PHP site's origin(s) to call this API.
CORS(app, resources={r"/api/*": {"origins": Config.ALLOWED_ORIGINS}})


@app.route("/api/health", methods=["GET"])
def health_check():
    """
    Basic health check.
    Confirms the Flask service is running AND can reach the MySQL
    database used by your existing PHP Hospital Management System.
    """
    db_ok, db_error = test_connection()

    response = {
        "service": "Smart Hospital Assistant API",
        "status": "ok" if db_ok else "degraded",
        "database_connected": db_ok,
    }
    if not db_ok:
        response["database_error"] = db_error

    return jsonify(response), (200 if db_ok else 500)


@app.route("/", methods=["GET"])
def index():
    return jsonify({
        "message": "Smart Hospital Assistant API is running.",
        "health_check": "/api/health"
    })


if __name__ == "__main__":
    app.run(host=Config.HOST, port=Config.PORT, debug=Config.DEBUG)
