"""
config.py
---------
Central configuration for the Smart Hospital Assistant Flask service.

IMPORTANT:
- This service does NOT modify your existing PHP project.
- It connects to the SAME MySQL database your PHP project already uses
  (read-only for now), using its own Python connection.
- Update the values below (or the .env file) to match your existing
  MySQL credentials from your PHP project's db config.
"""

import os
from dotenv import load_dotenv

# Load variables from a .env file if present (recommended for real credentials)
load_dotenv()


class Config:
    # ---------------------------------------------------------------
    # Flask settings
    # ---------------------------------------------------------------
    DEBUG = os.getenv("FLASK_DEBUG", "True") == "True"
    HOST = os.getenv("FLASK_HOST", "0.0.0.0")
    PORT = int(os.getenv("FLASK_PORT", 5000))

    # ---------------------------------------------------------------
    # CORS settings
    # ---------------------------------------------------------------
    # Set this to the exact origin(s) of your PHP hospital website.
    # Example: "http://localhost", "http://localhost/hospital_project",
    # or your production domain "https://yourhospital.com"
    ALLOWED_ORIGINS = os.getenv(
        "ALLOWED_ORIGINS",
        "http://localhost,http://localhost:80,http://127.0.0.1"
    ).split(",")

    # ---------------------------------------------------------------
    # MySQL database settings (SAME database as your PHP project)
    # ---------------------------------------------------------------
    DB_HOST = os.getenv("DB_HOST", "localhost")
    DB_PORT = int(os.getenv("DB_PORT", 3306))
    DB_USER = os.getenv("DB_USER", "root")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "")
    DB_NAME = os.getenv("DB_NAME", "hospital_management")

    # ---------------------------------------------------------------
    # Safety switch
    # ---------------------------------------------------------------
    # Per project requirements: the chatbot must NEVER write/modify
    # existing hospital data unless explicitly requested in a later
    # phase. This flag lets us hard-block any write operation until
    # we intentionally enable it in a future phase.
    ALLOW_WRITE_OPERATIONS = os.getenv("ALLOW_WRITE_OPERATIONS", "False") == "True"
