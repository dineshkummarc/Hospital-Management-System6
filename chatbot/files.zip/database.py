"""
database.py
-----------
Handles all MySQL connections for the Smart Hospital Assistant.

This connects to the SAME MySQL database used by your existing PHP
Hospital Management System. It does not create, alter, or drop any
tables. It only reads (and, in later phases, will very selectively
write) data using the tables that already exist:

    users, doctors, departments, patients, appointments, prescriptions

Usage:
    from database import get_connection

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM departments")
    rows = cursor.fetchall()
    cursor.close()
    conn.close()

Or, preferably, use the context manager:

    from database import db_cursor

    with db_cursor() as cursor:
        cursor.execute("SELECT * FROM departments")
        rows = cursor.fetchall()
"""

from contextlib import contextmanager
import mysql.connector
from mysql.connector import pooling, Error as MySQLError

from config import Config

_pool = None


def _init_pool():
    """Lazily initialize a connection pool (created on first use)."""
    global _pool
    if _pool is None:
        _pool = pooling.MySQLConnectionPool(
            pool_name="hospital_chatbot_pool",
            pool_size=5,
            host=Config.DB_HOST,
            port=Config.DB_PORT,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            database=Config.DB_NAME,
            autocommit=True,
        )
    return _pool


def get_connection():
    """Return a live MySQL connection from the pool."""
    pool = _init_pool()
    return pool.get_connection()


def test_connection():
    """
    Simple health check used by the /api/health route.
    Returns (True, None) on success or (False, error_message) on failure.
    """
    try:
        conn = get_connection()
        if conn.is_connected():
            conn.close()
            return True, None
        return False, "Connection object reported not connected."
    except MySQLError as err:
        return False, str(err)


@contextmanager
def db_cursor(dictionary=True, commit=False):
    """
    Context manager that yields a cursor and guarantees the
    connection/cursor are closed afterwards.

    dictionary=True  -> rows come back as dicts (column_name: value)
    commit=False     -> read-only by default (safe default per project rules)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=dictionary)
    try:
        yield cursor
        if commit:
            conn.commit()
    finally:
        cursor.close()
        conn.close()
