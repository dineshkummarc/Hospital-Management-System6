# Smart Hospital Assistant — Python API + Chat Widget

## Phase 2 — Chat Widget UI, AJAX, and PHP Integration

This phase adds the visible chatbot: a floating widget you can drop into
every page of your existing PHP Hospital Management System, plus the
AJAX layer that connects it to the Flask API from Phase 1.

**Nothing from Phase 1 was rewritten.** `app.py` only gained one new
route (`/api/chat`) so the widget has something real to talk to before
Phase 3 builds the actual symptom/intent engine.

## What's new in this ZIP

```
chatbot/
├── app.py                          (Phase 1 file + new /api/chat stub route)
├── config.py                       (unchanged)
├── database.py                     (unchanged)
├── requirements.txt                (unchanged)
├── .env.example                    (unchanged)
├── README.md                       (this file)
├── static/
│   ├── css/
│   │   └── chatbot.css             ← widget styling, light/dark theme
│   └── js/
│       └── chatbot.js              ← widget behavior + AJAX (fetch) calls
└── php-integration/
    └── chatbot-widget.php          ← the ONE file you include in your PHP project
```

## How the pieces fit together

```
Your PHP page (any page)
   │
   │  include 'chatbot-widget.php';   ← one line, right before </body>
   ▼
chatbot-widget.php
   │  - reads $_SESSION (read-only) to know if a user is logged in
   │  - prints the widget HTML (button + panel)
   │  - loads chatbot.css and chatbot.js FROM YOUR FLASK SERVER
   ▼
chatbot.js (runs in the browser)
   │  - handles open/close/minimize/clear/theme
   │  - on send: fetch() POST → http://<flask-host>/api/chat
   ▼
Flask /api/chat  (app.py)
   │  - reads {message, user} JSON
   │  - (Phase 3+: symptom engine, doctor search, appointments, FAQs)
   ▼
JSON response  → rendered back into the chat bubbles by chatbot.js
```

## Step-by-step integration into your existing PHP project

**1. Keep the Flask service running** (from Phase 1):
```bash
cd chatbot
python app.py
```
It should be reachable at `http://localhost:5000` (or wherever you deploy it).

**2. Copy `php-integration/chatbot-widget.php`** into your PHP project,
e.g. into an `includes/` folder you already have:
```
your-hms-project/
├── includes/
│   └── chatbot-widget.php     ← copied here
├── admin/
├── doctor/
├── patient/
└── ...
```

**3. Open `chatbot-widget.php` and set two things:**
- `$chatbotApiBase` — the URL where Flask is running (`http://localhost:5000`
  while developing; your real domain in production).
- The `$_SESSION[...]` key names in the "Read the logged-in user" section
  — update `user_id`, `role`, `name` to match whatever your actual login
  code stores in `$_SESSION`. This is what lets later phases answer
  "my appointment" / "my prescription" for a logged-in patient.

**4. Add ONE include line to your shared layout/footer** — the single
file that's already included at the bottom of every page (commonly
`footer.php`, `layout.php`, or similar), right before `</body>`:
```php
<?php include 'includes/chatbot-widget.php'; ?>
</body>
</html>
```
That's the only change to your existing PHP code. Every page that
includes your footer now gets the floating chatbot automatically —
admin, doctor, and patient modules alike.

**5. Confirm Bootstrap Icons is already loaded on your pages** (you
mentioned your project already uses it). The widget's icons (chat
bubble, send, trash, sun/moon, etc.) reuse your existing `bi bi-*`
classes rather than adding a new icon library.

**6. Open any page and test it:**
- The floating button should appear bottom-right.
- Click it → panel opens, shows a welcome message and 6 suggestion chips.
- Type a message or tap a chip → you should see a typing indicator,
  then a reply from Flask confirming the round trip worked.
- Try the theme toggle (sun/moon icon), minimize, close, and clear
  conversation buttons.
- Resize your browser to a phone width to confirm the responsive layout.

## Where should `static/css` and `static/js` live?

Two options — pick whichever fits your setup:

**Option A — Serve from Flask (recommended, what's wired up by default).**
Flask automatically serves anything in its `static/` folder. The include
file above already points `<link>` / `<script>` tags at
`http://<flask-host>/static/css/chatbot.css` and `.../static/js/chatbot.js`.
Nothing needs to be copied into your PHP project — one source of truth,
one thing to redeploy when the widget changes.

**Option B — Self-host inside your PHP project.**
If you'd rather everything be same-origin (no cross-origin requests for
the CSS/JS themselves — the `/api/chat` call still crosses origins
either way), copy `static/css/chatbot.css` and `static/js/chatbot.js`
into your own project's assets folder and change the `<link>`/`<script>`
paths in `chatbot-widget.php` to point at your local copies instead.

## About the `/api/chat` stub

Right now `/api/chat` in `app.py` just echoes back a confirmation message
— it proves the full pipeline (widget → AJAX → Flask → JSON → widget)
works before any real intelligence exists. The JSON shape it returns is
already what `chatbot.js` expects for the real thing:
```json
{
  "type": "text",
  "reply": "plain text shown in the bubble",
  "department": { "name": "Cardiology", "icon": "❤️", "reason": "..." },
  "doctors": [
    { "name": "Dr. A", "specialization": "Cardiologist", "experience": "8", "fee": "₹500" }
  ],
  "warning": "If symptoms become severe, seek emergency care immediately."
}
```
`department`, `doctors`, and `warning` are all optional — the widget
already knows how to render each of them as cards/banners inside a bot
message. Phase 3 replaces the placeholder logic inside the `chat()`
function in `app.py` with real keyword-based symptom matching and
department recommendations — **no changes to the widget will be needed**
for that to show up correctly.

## CORS reminder

`app.py`'s CORS setup only allows the origins listed in
`HMS_ALLOWED_ORIGINS` (see `.env.example` / `config.py`). Make sure that
matches exactly where your PHP site is served from (protocol + host +
port), or the browser will block the `/api/chat` request.

## Tested this phase

- `/api/ping` → `200 {"message": "pong"}`
- `/api/chat` with a normal message → `200`, structured JSON reply
- `/api/chat` with an empty message → `400`, friendly validation message
- `/api/chat` with a logged-in user payload → reply acknowledges the user id
- `chatbot.js` passed a Node syntax check; `app.py` / `config.py` /
  `database.py` compiled cleanly

## Next: Phase 3

Once the widget is live on your pages and you can see the placeholder
reply coming back from Flask, let me know and we'll move to **Phase 3**:
the Symptom Engine — keyword-group matching (`symptom_engine.py`),
department recommendation, and emergency-symptom warnings, replacing the
stub logic in `/api/chat`.
