"""
app.py
------
Entry point for the Smart Hospital Assistant Flask API.

Phase 1 scope ONLY:
    - Flask app setup
    - CORS setup (so your PHP/JS chat widget can call this API from
      the browser, since it runs on a different port than PHP)
    - A health-check endpoint to confirm Flask + MySQL are both alive

Nothing here talks to the chatbot logic yet (no symptom checker, no
doctor search, no appointments). Those come in later phases, each
registered as its own route / blueprint so app.py stays clean.

Run with:
    python app.py
"""

from flask import Flask, jsonify, request
from flask_cors import CORS

from config import config
from database import test_connection

app = Flask(__name__)

# ----------------------------------------------------------------------
# CORS
# Only allow the origins where your PHP hospital site actually runs.
# This keeps the API from being callable by random websites.
# ----------------------------------------------------------------------
CORS(
    app,
    resources={r"/api/*": {"origins": config.ALLOWED_ORIGINS}},
    supports_credentials=True,
)


@app.route("/api/health", methods=["GET"])
def health_check():
    """
    Simple endpoint to verify:
    1. The Flask service is running.
    2. The Flask service can reach the MySQL database used by the
       existing PHP Hospital Management System.

    Call this first after starting the server, and again after you
    point config.py at your real database credentials.
    """
    db_ok = test_connection()

    return jsonify({
        "status": "ok" if db_ok else "degraded",
        "service": "Smart Hospital Assistant API",
        "database_connected": db_ok,
    }), 200 if db_ok else 500


@app.route("/api/ping", methods=["GET"])
def ping():
    """Lightweight endpoint with no DB call - useful for a quick 'is Flask up' check."""
    return jsonify({"message": "pong"}), 200


@app.route("/api/chat", methods=["POST"])
def chat():
    """
    PHASE 2 STUB ENDPOINT.

    This exists so the chat widget's full UI -> AJAX -> Flask -> JSON ->
    UI round trip can be tested end-to-end right now, before the real
    intelligence exists.

    Phase 3 replaces the body of this function with calls into
    symptom_engine.py (keyword-group matching + department recommendation)
    and intents.py (natural language intent detection). The JSON response
    "contract" below (type / reply / department / doctors / warning) is
    already what chatbot.js expects, so the frontend will not need to
    change when Phase 3 lands.
    """
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    user = data.get("user") or {}

    if not message:
        return jsonify({
            "type": "text",
            "reply": "Please type a message so I can help.",
        }), 400

    # TEMPORARY placeholder logic - replaced by the real symptom/intent
    # engine in Phase 3. This only proves the pipeline works.
    reply_text = (
        f'Thanks — I received your message: "{message}". '
        "The symptom checker, department recommendations, and smart replies "
        "are being wired up next (Phase 3). This confirms the chat widget, "
        "the AJAX call, and the Flask API are all connected correctly."
    )

    if user.get("isLoggedIn"):
        reply_text += f" (Recognized you as a logged-in user, id {user.get('id')}.)"

    return jsonify({
        "type": "text",
        "reply": reply_text,
    }), 200


if __name__ == "__main__":
    app.run(
        host=config.FLASK_HOST,
        port=config.FLASK_PORT,
        debug=config.DEBUG,
    )
