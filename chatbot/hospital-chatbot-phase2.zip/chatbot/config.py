"""
config.py
---------
Central configuration for the Smart Hospital Assistant (Flask API).

This file holds settings only. It does NOT connect to anything by itself.
Update the values below (or better, set environment variables) to match
your existing Hospital Management System's MySQL database.

IMPORTANT:
This chatbot service connects to the SAME MySQL database your PHP project
already uses. It does not create new tables in Phase 1 - it only reads
existing ones (users, doctors, departments, patients, appointments,
prescriptions).
"""

import os


class Config:
    # ------------------------------------------------------------------
    # MySQL Database Configuration
    # Use the SAME credentials your PHP project (config.php / db.php) uses.
    # ------------------------------------------------------------------
    MYSQL_HOST = os.environ.get("HMS_DB_HOST", "localhost")
    MYSQL_PORT = int(os.environ.get("HMS_DB_PORT", 3306))
    MYSQL_USER = os.environ.get("HMS_DB_USER", "root")
    MYSQL_PASSWORD = os.environ.get("HMS_DB_PASSWORD", "")
    MYSQL_DATABASE = os.environ.get("HMS_DB_NAME", "hospital_management")

    # ------------------------------------------------------------------
    # Flask App Configuration
    # ------------------------------------------------------------------
    FLASK_HOST = os.environ.get("HMS_FLASK_HOST", "0.0.0.0")
    FLASK_PORT = int(os.environ.get("HMS_FLASK_PORT", 5000))
    DEBUG = os.environ.get("HMS_FLASK_DEBUG", "True") == "True"

    # ------------------------------------------------------------------
    # CORS Configuration
    # Add the exact origin(s) where your PHP site runs.
    # Examples: "http://localhost", "http://localhost/hospital_system",
    #           "https://yourdomain.com"
    # ------------------------------------------------------------------
    ALLOWED_ORIGINS = os.environ.get(
        "HMS_ALLOWED_ORIGINS",
        "http://localhost,http://127.0.0.1"
    ).split(",")


config = Config()
