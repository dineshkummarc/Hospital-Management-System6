# Smart Hospital Assistant — Python API + Chat Widget

## Phase 3 — Symptom Engine, Department Recommendation, Doctor Lookup

This phase makes the chatbot actually intelligent. `/api/chat` no longer
returns a placeholder — it now runs real keyword-based symptom analysis,
recommends a department, and queries your existing MySQL database for
active doctors in that department.

**Nothing from Phase 1 or 2 was rewritten.** The widget UI, its AJAX
call, and the JSON contract it already knew how to render (department /
doctors / warning / disclaimer) are unchanged — this phase just fills in
real logic behind `/api/chat` instead of the stub.

## What's new in this ZIP

```
chatbot/
├── app.py                  (Phase 1/2 file - /api/chat now calls the real engine)
├── config.py                (Phase 1/2 file + new DB schema mapping section)
├── database.py               (unchanged)
├── symptom_engine.py        ← NEW: keyword groups, department scoring, emergency detection
├── doctor_service.py        ← NEW: active-doctor lookup for a department
├── intents.py                ← NEW: greeting / thanks / symptom-or-other routing
├── requirements.txt          (unchanged)
├── .env.example               (unchanged)
├── README.md                  (this file)
├── static/
│   ├── css/chatbot.css      (Phase 2 file + small style for inline disclaimer)
│   └── js/chatbot.js         (Phase 2 file + renders the new "disclaimer" field)
└── php-integration/
    └── chatbot-widget.php    (unchanged)
```

## How a message flows through the system now

```
"I have chest pain and breathing difficulty"
   │
   ▼
intents.detect_intent()          → not a greeting/thanks → hand off
   │
   ▼
symptom_engine.analyze_symptoms()
   │  - scores every department's keyword list against the message
   │  - Cardiology wins (2 keyword matches: "chest pain", "breathing difficulty")
   │  - also flags is_emergency = True (both are emergency keywords)
   ▼
doctor_service.get_active_doctors_by_department("Cardiology")
   │  - SELECT ... FROM doctors JOIN departments
   │    WHERE department = 'Cardiology' AND status = 'active'
   ▼
app.py assembles the JSON response:
{
  "type": "symptom_result",
  "reply": "Based on what you described, I'd recommend Cardiology.",
  "department": { "name": "Cardiology", "icon": "❤️", "reason": "..." },
  "doctors": [ { "name": "...", "specialization": "...", "experience": "...", "fee": "₹800" } ],
  "disclaimer": "This recommendation is based only on the symptoms...",
  "warning": "Your symptoms may be serious. ... seek emergency medical care immediately."
}
   ▼
chatbot.js renders this as: bot bubble + department card + doctor cards
+ red warning banner + small italic disclaimer line
```

## ⚠️ Action required: confirm your database schema

`doctor_service.py` queries your `doctors` and `departments` tables using
column names that are **best-effort guesses** for a typical Hospital
Management System, since I don't have visibility into your actual table
structure. These are all defined in **one place** — the new "Database
Schema Mapping" section in `config.py` — so you don't need to touch any
SQL to fix them:

```python
TBL_DOCTORS = "doctors"
TBL_DEPARTMENTS = "departments"

DOCTORS_COL_ID = "id"
DOCTORS_COL_NAME = "name"
DOCTORS_COL_SPECIALIZATION = "specialization"
DOCTORS_COL_EXPERIENCE = "experience"
DOCTORS_COL_FEE = "consultation_fee"
DOCTORS_COL_DEPARTMENT_ID = "department_id"   # FK into departments table
DOCTORS_COL_STATUS = "status"                 # column marking active/inactive
DOCTORS_STATUS_ACTIVE_VALUE = "active"        # the value meaning "active" — could be 1, "Active", "approved", etc.

DEPARTMENTS_COL_ID = "id"
DEPARTMENTS_COL_NAME = "name"
```

**Before testing against your real database:** open your existing PHP
project's database (or the SQL that creates the `doctors` / `departments`
tables) and update any of the values above that don't match. Also check
that the department names stored in your `departments` table exactly
match the `db_name` values in `symptom_engine.py`'s `DEPARTMENT_KEYWORDS`
(e.g. `"Cardiology"`, `"ENT"`) — adjust either side if your naming/casing
differs.

If a column name is wrong, `doctor_service.py` won't crash the chatbot —
it catches the DB error, logs it to the Flask console, and the chatbot
still recommends the department, just without a doctor list, and tells
the user so.

## Keyword groups (in `symptom_engine.py`)

Nine departments are covered out of the box: Cardiology, Neurology,
Dermatology, Orthopedics, ENT, Gastroenterology, Pediatrics, Gynecology,
and General Medicine — each with a curated list of symptom phrases.

**To extend:** add a string to a department's `"keywords"` list, or copy
a whole department block to add a new one. Nothing else needs to change.

## Emergency detection

A separate `EMERGENCY_KEYWORDS` list (chest pain, breathing difficulty,
unconsciousness, severe bleeding, stroke, etc.) is checked independently
of department matching. If any of those phrases appear, the response
includes a `warning` field urging the user to seek emergency care —
regardless of which department was recommended.

## Medical disclaimer

`MEDICAL_DISCLAIMER` in `symptom_engine.py` is attached to **every**
symptom-result response as a `disclaimer` field in the JSON — not just
shown in the widget's static footer (which was already always visible
from Phase 2). `chatbot.js` now also renders it inline under each
symptom-related reply.

## Tested this phase

Ran the real `/api/chat` route through Flask's test client (with a
mocked doctor dataset standing in for the database):

| Input | Result |
|---|---|
| `"hello"` | Greeting reply, no symptom analysis run |
| `"thanks a lot"` | Thanks reply |
| `"I have chest pain and breathing difficulty"` | Cardiology recommended, 2 doctors returned, **emergency warning included** |
| `"my head hurts and I feel dizzy"` | Neurology recommended, 1 doctor returned, no warning |
| `"I feel great today"` | No keywords matched → friendly fallback message |
| `""` (empty) | `400`, validation message |

Also unit-tested independently:
- `symptom_engine.analyze_symptoms()` against 7 sample messages spanning
  6 departments, an emergency case, and a non-symptom message.
- `doctor_service.get_active_doctors_by_department()` — confirmed the
  generated SQL uses the `config.py` column names correctly, confirmed
  fee formatting (`₹800`), and confirmed a simulated DB/schema error
  returns an empty list instead of crashing the request.

All `.py` files compile cleanly; `chatbot.js` passes a Node syntax check.

## Next: Phase 4

Phase 4 focuses on deepening doctor search (e.g. searching by doctor
name directly, filtering by specialization keyword, "who's available
today"). Once you've pointed `config.py`'s schema section at your real
tables and confirmed doctor cards show up correctly for a few symptom
messages, let me know and we'll move on.
