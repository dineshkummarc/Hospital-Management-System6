"""
app.py
------
Entry point for the Smart Hospital Assistant Flask API.

Phase 1: Flask setup, folder structure, database connection.
Phase 2: Chat widget UI, AJAX, PHP integration (added the /api/chat route
         as a stub).
Phase 3 (this update): /api/chat now uses real intent detection
         (intents.py) and symptom analysis (symptom_engine.py) to
         recommend a department, then looks up active doctors for that
         department (doctor_service.py). No frontend changes were
         needed - chatbot.js already knew how to render department/
         doctors/warning payloads from Phase 2.

Run with:
    python app.py
"""

from flask import Flask, jsonify, request
from flask_cors import CORS

from config import config
from database import test_connection
from intents import detect_intent, INTENT_GREETING, INTENT_THANKS
from symptom_engine import analyze_symptoms, MEDICAL_DISCLAIMER, EMERGENCY_WARNING
from doctor_service import get_active_doctors_by_department, format_doctors_for_response

app = Flask(__name__)

# ----------------------------------------------------------------------
# CORS
# Only allow the origins where your PHP hospital site actually runs.
# This keeps the API from being callable by random websites.
# ----------------------------------------------------------------------
CORS(
    app,
    resources={r"/api/*": {"origins": config.ALLOWED_ORIGINS}},
    supports_credentials=True,
)


@app.route("/api/health", methods=["GET"])
def health_check():
    """
    Simple endpoint to verify:
    1. The Flask service is running.
    2. The Flask service can reach the MySQL database used by the
       existing PHP Hospital Management System.

    Call this first after starting the server, and again after you
    point config.py at your real database credentials.
    """
    db_ok = test_connection()

    return jsonify({
        "status": "ok" if db_ok else "degraded",
        "service": "Smart Hospital Assistant API",
        "database_connected": db_ok,
    }), 200 if db_ok else 500


@app.route("/api/ping", methods=["GET"])
def ping():
    """Lightweight endpoint with no DB call - useful for a quick 'is Flask up' check."""
    return jsonify({"message": "pong"}), 200


@app.route("/api/chat", methods=["POST"])
def chat():
    """
    Main chatbot endpoint.

    Flow:
        1. Detect coarse intent (greeting / thanks / symptom-or-other).
        2. Greeting/thanks get a short canned reply - no need to run
           symptom analysis on "hello".
        3. Everything else goes through the symptom engine. If keywords
           matched, recommend a department, fetch active doctors for it,
           and always include the medical disclaimer. If the message
           contained emergency keywords, add a warning too.
        4. If nothing matched at all, return a friendly fallback (this
           is also where Phase 4-6 features - "my appointment", "my
           prescription", hospital FAQs - will plug in).
    """
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    user = data.get("user") or {}

    if not message:
        return jsonify({
            "type": "text",
            "reply": "Please type a message so I can help.",
        }), 400

    intent = detect_intent(message)

    if intent == INTENT_GREETING:
        return jsonify({
            "type": "text",
            "reply": "Hello! Tell me your symptoms, or ask about a department, "
                     "and I'll point you in the right direction.",
        }), 200

    if intent == INTENT_THANKS:
        return jsonify({
            "type": "text",
            "reply": "You're welcome! Let me know if there's anything else I can help with.",
        }), 200

    # intent == symptom-or-other: run the symptom engine
    result = analyze_symptoms(message)

    if not result["is_symptom"]:
        # No department keywords matched. Phase 4-6 will extend this
        # branch to handle "my appointment", "my prescription", and
        # general hospital FAQs (timings, booking, contact, etc.).
        return jsonify({
            "type": "text",
            "reply": "I couldn't match that to a specific symptom yet. Try describing "
                     "how you're feeling (e.g. \"I have a headache\" or \"chest pain\"), "
                     "or use one of the quick options below.",
        }), 200

    doctors_raw = get_active_doctors_by_department(result["db_name"])
    doctors = format_doctors_for_response(doctors_raw)

    response = {
        "type": "symptom_result",
        "reply": f"Based on what you described, I'd recommend {result['department_name']}.",
        "department": {
            "name": result["department_name"],
            "icon": result["icon"],
            "reason": result["reason"],
        },
        "doctors": doctors,
        "disclaimer": MEDICAL_DISCLAIMER,
    }

    if result["is_emergency"]:
        response["warning"] = EMERGENCY_WARNING

    if not doctors:
        # Department matched, but no active doctors found - still useful
        # to the user, just say so rather than showing an empty list.
        response["reply"] += (
            " I couldn't find an active doctor listed for this department right now - "
            "please check the Departments page or contact the front desk."
        )

    return jsonify(response), 200


if __name__ == "__main__":
    app.run(
        host=config.FLASK_HOST,
        port=config.FLASK_PORT,
        debug=config.DEBUG,
    )
