"""
config.py
---------
Central configuration for the Smart Hospital Assistant (Flask API).

This file holds settings only. It does NOT connect to anything by itself.
Update the values below (or better, set environment variables) to match
your existing Hospital Management System's MySQL database.

IMPORTANT:
This chatbot service connects to the SAME MySQL database your PHP project
already uses. It does not create new tables in Phase 1 - it only reads
existing ones (users, doctors, departments, patients, appointments,
prescriptions).
"""

import os


class Config:
    # ------------------------------------------------------------------
    # MySQL Database Configuration
    # Use the SAME credentials your PHP project (config.php / db.php) uses.
    # ------------------------------------------------------------------
    MYSQL_HOST = os.environ.get("HMS_DB_HOST", "localhost")
    MYSQL_PORT = int(os.environ.get("HMS_DB_PORT", 3306))
    MYSQL_USER = os.environ.get("HMS_DB_USER", "root")
    MYSQL_PASSWORD = os.environ.get("HMS_DB_PASSWORD", "")
    MYSQL_DATABASE = os.environ.get("HMS_DB_NAME", "hospital_management")

    # ------------------------------------------------------------------
    # Flask App Configuration
    # ------------------------------------------------------------------
    FLASK_HOST = os.environ.get("HMS_FLASK_HOST", "0.0.0.0")
    FLASK_PORT = int(os.environ.get("HMS_FLASK_PORT", 5000))
    DEBUG = os.environ.get("HMS_FLASK_DEBUG", "True") == "True"

    # ------------------------------------------------------------------
    # CORS Configuration
    # Add the exact origin(s) where your PHP site runs.
    # Examples: "http://localhost", "http://localhost/hospital_system",
    #           "https://yourdomain.com"
    # ------------------------------------------------------------------
    ALLOWED_ORIGINS = os.environ.get(
        "HMS_ALLOWED_ORIGINS",
        "http://localhost,http://127.0.0.1"
    ).split(",")

    # ------------------------------------------------------------------
    # Database Schema Mapping
    # ------------------------------------------------------------------
    # These constants exist so Phase 3's doctor lookup query can be
    # pointed at YOUR real table/column names by editing values here,
    # instead of hunting through SQL strings inside doctor_service.py.
    #
    # IMPORTANT: these are best-effort common names for a Hospital
    # Management System. Open your existing PHP project's database
    # (or db.php / your `doctors` and `departments` table definitions)
    # and update anything below that doesn't match your real schema.
    # ------------------------------------------------------------------
    TBL_DOCTORS = "doctors"
    TBL_DEPARTMENTS = "departments"

    DOCTORS_COL_ID = "id"
    DOCTORS_COL_NAME = "name"
    DOCTORS_COL_SPECIALIZATION = "specialization"
    DOCTORS_COL_EXPERIENCE = "experience"          # numeric years
    DOCTORS_COL_FEE = "consultation_fee"
    DOCTORS_COL_DEPARTMENT_ID = "department_id"    # FK into departments table
    DOCTORS_COL_STATUS = "status"                  # column marking active/inactive

    # The value stored in DOCTORS_COL_STATUS that means "this doctor is
    # active / approved / visible". Change to 1, "Active", "approved",
    # etc. to match your actual data.
    DOCTORS_STATUS_ACTIVE_VALUE = "active"

    DEPARTMENTS_COL_ID = "id"
    DEPARTMENTS_COL_NAME = "name"


config = Config()
