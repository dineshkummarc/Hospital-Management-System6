"""
doctor_service.py
-------------------
Looks up ACTIVE doctors for a given department from your EXISTING
MySQL database (the same `doctors` and `departments` tables your PHP
Hospital Management System already uses).

This module is READ-ONLY: it only ever runs SELECT queries. It does not
insert, update, or delete anything.

Table/column names come from config.py so this file doesn't need to
change if your schema uses different naming — see the "Database Schema
Mapping" section in config.py.
"""

from database import run_query
from config import config


def get_active_doctors_by_department(db_department_name, limit=5):
    """
    Fetch active doctors belonging to a department.

    Args:
        db_department_name (str): department name as stored in the
            departments table (e.g. "Cardiology"). This should match
            the "db_name" value produced by symptom_engine.analyze_symptoms().
        limit (int): max number of doctors to return.

    Returns:
        list[dict]: each dict has keys: id, name, specialization,
        experience, fee. Empty list if none found OR if the query fails
        (a DB/schema mismatch should never crash the chatbot - see the
        try/except below).
    """
    cfg = config

    sql = f"""
        SELECT
            doc.{cfg.DOCTORS_COL_ID} AS id,
            doc.{cfg.DOCTORS_COL_NAME} AS name,
            doc.{cfg.DOCTORS_COL_SPECIALIZATION} AS specialization,
            doc.{cfg.DOCTORS_COL_EXPERIENCE} AS experience,
            doc.{cfg.DOCTORS_COL_FEE} AS fee
        FROM {cfg.TBL_DOCTORS} doc
        INNER JOIN {cfg.TBL_DEPARTMENTS} dept
            ON doc.{cfg.DOCTORS_COL_DEPARTMENT_ID} = dept.{cfg.DEPARTMENTS_COL_ID}
        WHERE dept.{cfg.DEPARTMENTS_COL_NAME} = %s
          AND doc.{cfg.DOCTORS_COL_STATUS} = %s
        ORDER BY doc.{cfg.DOCTORS_COL_EXPERIENCE} DESC
        LIMIT %s
    """

    try:
        rows = run_query(
            sql,
            (db_department_name, cfg.DOCTORS_STATUS_ACTIVE_VALUE, limit),
        )
        return rows or []
    except Exception as e:
        # A schema mismatch (wrong table/column name) or a DB outage
        # should degrade gracefully - the chatbot still recommends a
        # department, just without a doctor list - rather than crashing
        # the whole /api/chat request.
        print(f"[doctor_service.py] Failed to fetch doctors for "
              f"'{db_department_name}': {e}")
        return []


def format_doctors_for_response(doctors):
    """
    Convert raw DB rows into the shape chatbot.js already knows how to
    render as doctor cards: name, specialization, experience, fee.
    Values are cast to strings/formatted so the frontend never has to
    guess about types coming back from MySQL.
    """
    formatted = []
    for doc in doctors:
        experience = doc.get("experience")
        fee = doc.get("fee")

        formatted.append({
            "name": doc.get("name") or "Unnamed Doctor",
            "specialization": doc.get("specialization") or "",
            "experience": str(experience) if experience is not None else "",
            "fee": _format_fee(fee),
        })
    return formatted


def _format_fee(fee):
    """Best-effort formatting for a consultation fee value from the DB."""
    if fee is None:
        return ""
    try:
        return f"₹{float(fee):.0f}"
    except (TypeError, ValueError):
        return str(fee)
