"""
intents.py
----------
Lightweight intent detection for routing chat messages.

Phase 3 only needs to tell apart a handful of intents so the symptom
engine doesn't try to "diagnose" a simple "hello". Later phases
(appointment lookup, prescription lookup, hospital FAQ) will extend
detect_intent() with more branches - the function signature and return
values are designed to stay stable as that grows.

This is intentionally simple keyword/phrase matching, consistent with
the "no heavy AI frameworks" requirement for the whole project.
"""

GREETING_PHRASES = [
    "hi", "hello", "hey", "hii", "hola",
    "good morning", "good afternoon", "good evening",
]

THANKS_PHRASES = [
    "thanks", "thank you", "thankyou", "thx", "tysm", "appreciate it",
]

# Intent constants (used by app.py so route logic doesn't rely on raw strings)
INTENT_GREETING = "greeting"
INTENT_THANKS = "thanks"
INTENT_SYMPTOM_OR_OTHER = "symptom_or_other"


def detect_intent(message):
    """
    Classify a message into a coarse intent bucket.

    Returns one of:
        INTENT_GREETING          - e.g. "hi", "good morning"
        INTENT_THANKS            - e.g. "thanks", "thank you"
        INTENT_SYMPTOM_OR_OTHER  - everything else; app.py hands this
                                    to symptom_engine.analyze_symptoms()
                                    to decide what it actually is.
    """
    normalized = (message or "").strip().lower()

    if not normalized:
        return INTENT_SYMPTOM_OR_OTHER

    # Greeting: message IS a greeting phrase, or starts with one
    # (e.g. "hello there", "hi, i have a question").
    if any(normalized == g or normalized.startswith(g) for g in GREETING_PHRASES):
        return INTENT_GREETING

    if any(t in normalized for t in THANKS_PHRASES):
        return INTENT_THANKS

    return INTENT_SYMPTOM_OR_OTHER
