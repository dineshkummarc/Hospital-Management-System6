/* ==========================================================================
   chatbot.js
   Smart Hospital Assistant — floating chat widget behavior + AJAX layer.

   This file:
   1. Builds/controls the widget UI (open, close, minimize, clear, theme).
   2. Sends user messages to the Flask API via fetch() (AJAX) and renders
      whatever structured response comes back (plain text, department
      recommendation cards, doctor cards, emergency warnings).

   It expects `window.HMS_CHATBOT_CONFIG` to already be defined by the PHP
   include (chatbot-widget.php) before this script runs, e.g.:

     window.HMS_CHATBOT_CONFIG = {
       apiBase: "http://localhost:5000",
       user: { isLoggedIn: false, id: null, role: null, name: null }
     };

   No build step, no framework — plain JS so it can be dropped into any
   PHP page as-is.
   ========================================================================== */

(function () {
  "use strict";

  const CONFIG = window.HMS_CHATBOT_CONFIG || { apiBase: "", user: { isLoggedIn: false } };
  const API_BASE = (CONFIG.apiBase || "").replace(/\/$/, "");
  const CHAT_ENDPOINT = `${API_BASE}/api/chat`;

  const STORAGE_KEY = "hms_chatbot_history_v1";
  const THEME_KEY = "hms_chatbot_theme";

  // ------------------------------------------------------------------
  // Element references (all markup already exists in chatbot-widget.php)
  // ------------------------------------------------------------------
  const root = document.getElementById("hms-chatbot-root");
  const toggleBtn = document.getElementById("hms-chatbot-toggle");
  const panel = document.getElementById("hms-chatbot-panel");
  const body = document.getElementById("hms-chat-body");
  const form = document.getElementById("hms-chat-form");
  const input = document.getElementById("hms-chat-input");
  const sendBtn = document.getElementById("hms-chat-send");
  const minimizeBtn = document.getElementById("hms-minimize-chat");
  const closeBtn = document.getElementById("hms-close-chat");
  const clearBtn = document.getElementById("hms-clear-chat");
  const themeBtn = document.getElementById("hms-theme-toggle");
  const suggestionsWrap = document.getElementById("hms-suggestions");

  if (!root || !panel) {
    console.warn("[hms-chatbot] Widget markup not found on this page.");
    return;
  }

  // ------------------------------------------------------------------
  // State
  // ------------------------------------------------------------------
  let isOpen = false;
  let isMinimized = false;
  let isSending = false;
  let history = loadHistory();

  // ------------------------------------------------------------------
  // Theme
  // ------------------------------------------------------------------
  function initTheme() {
    const saved = localStorage.getItem(THEME_KEY);
    const preferred = saved || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
    root.setAttribute("data-theme", preferred);
  }

  function toggleTheme() {
    const current = root.getAttribute("data-theme") === "dark" ? "dark" : "light";
    const next = current === "dark" ? "light" : "dark";
    root.setAttribute("data-theme", next);
    localStorage.setItem(THEME_KEY, next);
  }

  // ------------------------------------------------------------------
  // Panel open / close / minimize
  // ------------------------------------------------------------------
  function openPanel() {
    isOpen = true;
    isMinimized = false;
    panel.classList.remove("hms-hidden", "hms-minimized");
    toggleBtn.setAttribute("aria-expanded", "true");
    if (history.length === 0) {
      renderWelcomeMessage();
    }
    scrollToBottom();
    setTimeout(() => input && input.focus(), 150);
  }

  function closePanel() {
    isOpen = false;
    isMinimized = false;
    panel.classList.add("hms-hidden");
    panel.classList.remove("hms-minimized");
    toggleBtn.setAttribute("aria-expanded", "false");
  }

  function toggleMinimize() {
    isMinimized = !isMinimized;
    panel.classList.toggle("hms-minimized", isMinimized);
  }

  function togglePanel() {
    if (isOpen) {
      closePanel();
    } else {
      openPanel();
    }
  }

  // ------------------------------------------------------------------
  // Message rendering
  // ------------------------------------------------------------------
  function renderWelcomeMessage() {
    appendBotMessage({
      type: "text",
      reply:
        "Hi, I'm your Smart Hospital Assistant. Tell me your symptoms, ask about a department, " +
        "or use one of the quick options below to get started.",
    });
  }

  function scrollToBottom() {
    requestAnimationFrame(() => {
      body.scrollTop = body.scrollHeight;
    });
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str == null ? "" : String(str);
    return div.innerHTML;
  }

  function appendUserMessage(text) {
    const row = document.createElement("div");
    row.className = "hms-msg-row hms-user";
    row.innerHTML = `
      <div class="hms-msg-avatar"><i class="bi bi-person-fill"></i></div>
      <div class="hms-bubble"><p>${escapeHtml(text)}</p></div>
    `;
    body.appendChild(row);
    history.push({ role: "user", text });
    saveHistory();
    scrollToBottom();
  }

  /**
   * Renders a bot response. Supports a simple structured contract so
   * later phases (symptom engine, doctor search, appointments) can
   * return richer payloads without any changes to this file:
   *
   * {
   *   type: "text",
   *   reply: "plain text message",
   *   department: { name, icon, reason } | undefined,
   *   doctors: [{ name, specialization, experience, fee }] | undefined,
   *   warning: "emergency warning text" | undefined,
   *   disclaimer: true | undefined
   * }
   */
  function appendBotMessage(payload) {
    const row = document.createElement("div");
    row.className = "hms-msg-row hms-bot";

    let inner = "";

    if (payload.reply) {
      inner += `<p>${escapeHtml(payload.reply)}</p>`;
    }

    if (payload.department) {
      inner += `
        <div class="hms-card">
          <div class="hms-card-title">${escapeHtml(payload.department.icon || "🏥")} ${escapeHtml(payload.department.name)}</div>
          ${payload.department.reason ? `<div class="hms-card-meta">${escapeHtml(payload.department.reason)}</div>` : ""}
        </div>`;
    }

    if (Array.isArray(payload.doctors) && payload.doctors.length > 0) {
      inner += payload.doctors
        .map(
          (doc) => `
        <div class="hms-card">
          <div class="hms-card-title">${escapeHtml(doc.name)}</div>
          <div class="hms-card-meta">${escapeHtml(doc.specialization || "")}${doc.experience ? " • " + escapeHtml(doc.experience) + " yrs exp" : ""}</div>
          ${doc.fee ? `<div class="hms-card-meta">Consultation fee: ${escapeHtml(doc.fee)}</div>` : ""}
        </div>`
        )
        .join("");
    }

    if (payload.warning) {
      inner += `
        <div class="hms-warning-banner">
          <i class="bi bi-exclamation-triangle-fill"></i>
          <span>${escapeHtml(payload.warning)}</span>
        </div>`;
    }

    if (payload.disclaimer) {
      inner += `<p class="hms-inline-disclaimer">${escapeHtml(payload.disclaimer)}</p>`;
    }

    row.innerHTML = `
      <div class="hms-msg-avatar"><i class="bi bi-heart-pulse-fill"></i></div>
      <div class="hms-bubble">${inner}</div>
    `;
    body.appendChild(row);
    history.push({ role: "bot", payload });
    saveHistory();
    scrollToBottom();
  }

  function showTypingIndicator() {
    const row = document.createElement("div");
    row.className = "hms-msg-row hms-bot";
    row.id = "hms-typing-row";
    row.innerHTML = `
      <div class="hms-msg-avatar"><i class="bi bi-heart-pulse-fill"></i></div>
      <div class="hms-bubble">
        <div class="hms-typing"><span></span><span></span><span></span></div>
      </div>
    `;
    body.appendChild(row);
    scrollToBottom();
  }

  function hideTypingIndicator() {
    const row = document.getElementById("hms-typing-row");
    if (row) row.remove();
  }

  // ------------------------------------------------------------------
  // History persistence (per-browser, not tied to PHP session)
  // ------------------------------------------------------------------
  function saveHistory() {
    try {
      // Cap stored history so localStorage doesn't grow unbounded
      const trimmed = history.slice(-50);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
    } catch (e) {
      // localStorage may be unavailable (private browsing, quota) - fail silently
    }
  }

  function loadHistory() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function replayHistory() {
    history.forEach((entry) => {
      if (entry.role === "user") {
        const row = document.createElement("div");
        row.className = "hms-msg-row hms-user";
        row.innerHTML = `
          <div class="hms-msg-avatar"><i class="bi bi-person-fill"></i></div>
          <div class="hms-bubble"><p>${escapeHtml(entry.text)}</p></div>
        `;
        body.appendChild(row);
      } else if (entry.role === "bot") {
        const savedHistory = history; // appendBotMessage would push again, so render manually
        const row = document.createElement("div");
        row.className = "hms-msg-row hms-bot";
        const payload = entry.payload || {};
        let inner = payload.reply ? `<p>${escapeHtml(payload.reply)}</p>` : "";
        row.innerHTML = `
          <div class="hms-msg-avatar"><i class="bi bi-heart-pulse-fill"></i></div>
          <div class="hms-bubble">${inner}</div>
        `;
        body.appendChild(row);
      }
    });
    scrollToBottom();
  }

  function clearConversation() {
    history = [];
    saveHistory();
    body.innerHTML = "";
    renderWelcomeMessage();
  }

  // ------------------------------------------------------------------
  // AJAX: send message to Flask API
  // ------------------------------------------------------------------
  async function sendMessage(text) {
    const message = (text || "").trim();
    if (!message || isSending) return;

    appendUserMessage(message);
    input.value = "";
    setSending(true);
    showTypingIndicator();

    try {
      const response = await fetch(CHAT_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message,
          user: CONFIG.user || {},
        }),
      });

      hideTypingIndicator();

      if (!response.ok) {
        throw new Error(`Server responded with status ${response.status}`);
      }

      const data = await response.json();
      appendBotMessage(data);
    } catch (err) {
      hideTypingIndicator();
      appendBotMessage({
        type: "text",
        reply:
          "Sorry, I couldn't reach the hospital assistant service right now. " +
          "Please try again in a moment, or contact the front desk for urgent help.",
      });
      console.error("[hms-chatbot] Chat request failed:", err);
    } finally {
      setSending(false);
    }
  }

  function setSending(state) {
    isSending = state;
    sendBtn.disabled = state;
  }

  // ------------------------------------------------------------------
  // Event wiring
  // ------------------------------------------------------------------
  toggleBtn.addEventListener("click", togglePanel);
  closeBtn.addEventListener("click", closePanel);
  minimizeBtn.addEventListener("click", toggleMinimize);
  clearBtn.addEventListener("click", clearConversation);
  themeBtn.addEventListener("click", toggleTheme);

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    sendMessage(input.value);
  });

  suggestionsWrap.addEventListener("click", (e) => {
    const chip = e.target.closest(".hms-chip");
    if (!chip) return;
    sendMessage(chip.dataset.message || chip.textContent);
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && isOpen) {
      closePanel();
    }
  });

  // ------------------------------------------------------------------
  // Init
  // ------------------------------------------------------------------
  initTheme();
  if (history.length > 0) {
    replayHistory();
  }
})();
